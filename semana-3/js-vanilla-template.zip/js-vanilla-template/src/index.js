// EXERCÍCIO 1

// const primeiroValor = 3
// const segundoValor = 4 
// const terceiroValor = 5
// const quartoValor = 234

// const resultado1 = primeiroValor + segundoValor
// const resultado2 = (primeiroValor * terceiroValor) / 2
// const resultado3 = (terceiroValor - segundoValor) * -1
// const resultado4 = quartoValor % terceiroValor

// console.log(resultado4)


// EXERCÍCIO 2 

// const primeiroValor = 5
// const segundoValor = 7

// const resultado1 = primeiroValor === segundoValor
// const resultado2 = primeiroValor !== segundoValor
// const resultado3 = primeiroValor > segundoValor
// const resultado4 = primeiroValor < segundoValor

// console.log(resultado3)
// console.log(resultado4)

// EXERCÍCIO 3

// const a = true 
// const b = false 
// const c = true
// const d = false

// // const resultado1 = a && b 
// // const resultado2 = b && c
// // const resultado3 = a && c
// // const resultado4 = a && b && c


// // EXERCÍCIO 4

// const resultado1 = a || b
// const resultado2 = b || c
// const resultado3 = a || c
// const resultado4 = a || b || c
// const resultado5 = b || d

// console.log(resultado5)

// // EXERCÍCIO 5

// const meuArray = [1, 2, 3, 4, 5, 6]

// meuArray.push(7)


// meuArray.splice(3, 2)

// console.log(meuArray)
// console.log(meuArray.length)

// EXERCÍCIO 6 

const nome = "pedro"
const sobrenome = "severo"
const nomeCompleto = nome + " " + sobrenome

console.log(nome.length)
console.log(sobrenome.length)
console.log(nomeCompleto.length)
console.log(nomeCompleto)